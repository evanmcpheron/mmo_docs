extends "res://tests/rendering/outlines_probe.gd"

func _execute() -> void:
	_path_index = 0
	_frame = 0
	_zooms.select(0)
	_lights.select(0)
	_antialiasing.select(0)
	_toon.button_pressed = true
	_views.select(0)
	_apply()
	var surfaces: Array[ShaderMaterial] = []
	var meshes: Array[MeshInstance3D] = []
	ReferenceWorld.AssetLibrary.collect_meshes(_reference, meshes)
	for mesh: MeshInstance3D in meshes:
		if mesh == _posts[_reference]:
			continue
		for index: int in range(mesh.mesh.get_surface_count()):
			var material: Material = mesh.get_active_material(index)
			if material is ShaderMaterial:
				surfaces.append(material)
	var rows: Array[Dictionary] = []
	var captures: Array[String] = []
	var base_code: String = Materials.TOON.code
	for mode: String in ["current", "constant-attenuation", "attenuation16", "irradiance-bands"]:
		var shader: Shader = Shader.new()
		shader.code = base_code
		if mode == "constant-attenuation":
			shader.code = shader.code.replace("* ATTENUATION *", "* 1.0 *")
		if mode == "attenuation16":
			shader.code = shader.code.replace("* ATTENUATION *", "* (round(ATTENUATION * 16.0) / 16.0) *")
		if mode == "irradiance-bands":
			shader.code = shader.code.replace("float incidence = dot(lighting_normal, LIGHT);", "float incidence = max(dot(lighting_normal, LIGHT), 0.0) * ATTENUATION;")
			shader.code = shader.code.replace("LIGHT_COLOR * ATTENUATION * band", "LIGHT_COLOR * band")
		for material: ShaderMaterial in surfaces:
			material.shader = shader
			material.set_shader_parameter("band_values", Vector3(0.0, 0.55, 1.0) if mode == "irradiance-bands" else Vector3(0.22, 0.55, 1.0))
		for warmup: int in range(16):
			await RenderingServer.frame_post_draw
		var first: PackedByteArray
		var previous: PackedByteArray
		var maximum_changed: int = 0
		var maximum_delta: int = 0
		var atlas: Image = Image.create(386, 218 * 32, false, Image.FORMAT_RGB8)
		for frame: int in range(32):
			if mode == "reapply":
				_apply()
			await _settle()
			var image: Image = _reference.get_texture().get_image()
			image.convert(Image.FORMAT_RGB8)
			var bytes: PackedByteArray = image.get_data()
			if frame == 0:
				var still_name: String = mode + ".png"
				if image.save_png(_request["output"].path_join(still_name)) != OK:
					_fail("Cannot retain illumination still.")
					return
				captures.append(still_name)
				first = bytes
				previous = bytes
			for reference: PackedByteArray in [first, previous]:
				var difference: Dictionary = Fixtures.color_difference(bytes, reference)
				maximum_changed = maxi(maximum_changed, difference["changed_pixels"])
				maximum_delta = maxi(maximum_delta, difference["max_rgb_delta"])
			previous = bytes
			for y: int in range(218):
				atlas.blit_rect(image, Rect2i(0, y, 386, 1), Vector2i(0, y * 32 + frame))
		var filename: String = mode + "-frames.png"
		if atlas.save_png(_request["output"].path_join(filename)) != OK:
			_fail("Cannot retain stationary deep investigation.")
			return
		captures.append(filename)
		rows.append({"mode": mode, "frames": 32, "max_changed_pixels": maximum_changed,
			"max_rgb_delta": maximum_delta, "executed_shader": shader.code})
	print(JSON.stringify({"event": "isolation-report", "observations": rows,
		"captures": captures, "debanding": _reference.use_debanding,
		"taa": _reference.use_taa, "scaling": _reference.scaling_3d_scale}))
	get_tree().quit(0)
