extends Control

const TOON = preload("res://fixtures/rendering/toon.gdshader")

var _world: SubViewport = SubViewport.new()
var _camera: Camera3D = Camera3D.new()
var _sun: DirectionalLight3D = DirectionalLight3D.new()
var _environment: Environment = Environment.new()
var _samples: Array[Dictionary] = []
var _output: String

func _ready() -> void:
	var arguments: PackedStringArray = OS.get_cmdline_user_args()
	var request: Variant = JSON.parse_string(FileAccess.get_file_as_string(arguments[0]))
	_output = request["output"]
	_world.size = Vector2i(384, 216)
	_world.own_world_3d = true
	_world.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	add_child(_world)
	_camera.position.z = 10.0
	_camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	_camera.size = 6.0
	_world.add_child(_camera)
	_camera.current = true
	_world.add_child(_sun)
	var environment_node: WorldEnvironment = WorldEnvironment.new()
	_environment.background_mode = Environment.BG_COLOR
	_environment.background_color = Color.BLACK
	_environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	_environment.ambient_light_color = Color.WHITE
	_environment.reflected_light_source = Environment.REFLECTION_SOURCE_DISABLED
	environment_node.environment = _environment
	_world.add_child(environment_node)
	var corrected_shader: Shader = Shader.new()
	corrected_shader.code = TOON.code.replace("ALBEDO * LIGHT_COLOR", "LIGHT_COLOR")
	var colors: Array[Color] = [Color(0.2, 0.2, 0.2), Color(0.5, 0.5, 0.5),
		Color(0.8, 0.8, 0.8), Color(0.5, 0.25, 0.1), Color(0.1, 0.3, 0.6)]
	for row: int in range(3):
		for column: int in range(colors.size()):
			var mesh: MeshInstance3D = MeshInstance3D.new()
			var quad: QuadMesh = QuadMesh.new()
			quad.size = Vector2(1.6, 1.6)
			mesh.mesh = quad
			mesh.position = Vector3((column - 2) * 2, (1 - row) * 2, 0)
			if row == 0:
				var standard: StandardMaterial3D = StandardMaterial3D.new()
				standard.albedo_color = colors[column]
				standard.diffuse_mode = BaseMaterial3D.DIFFUSE_LAMBERT
				standard.metallic_specular = 0.0
				standard.roughness = 1.0
				mesh.material_override = standard
			else:
				var custom: ShaderMaterial = ShaderMaterial.new()
				custom.shader = TOON if row == 1 else corrected_shader
				custom.set_shader_parameter("albedo_tint", colors[column])
				custom.set_shader_parameter("band_thresholds", Vector2(0.2, 0.65))
				custom.set_shader_parameter("band_values", Vector3.ONE)
				mesh.material_override = custom
			_world.add_child(mesh)
			_samples.append({"row": row, "column": column, "position": mesh.position,
				"albedo_srgb": colors[column].to_html()})
	_execute.call_deferred()

func _execute() -> void:
	var captures: Array[String] = []
	var observations: Array[Dictionary] = []
	for preset: String in ["direct", "ambient", "mixed"]:
		_sun.light_energy = 0.0 if preset == "ambient" else 1.0
		_environment.ambient_light_energy = 0.0 if preset == "direct" else 0.3
		for frame: int in range(16):
			await RenderingServer.frame_post_draw
		var image: Image = _world.get_texture().get_image()
		image.convert(Image.FORMAT_RGB8)
		var filename: String = "albedo-%s.png" % preset
		if image.save_png(_output.path_join(filename)) != OK:
			push_error("Cannot save isolated lighting image.")
			get_tree().quit(2)
			return
		captures.append(filename)
		for sample: Dictionary in _samples:
			var pixel: Vector2 = _camera.unproject_position(sample["position"])
			var color: Color = image.get_pixelv(Vector2i(pixel))
			var linear: Color = color.srgb_to_linear()
			observations.append({"preset": preset, "row": sample["row"],
				"column": sample["column"], "albedo_srgb": sample["albedo_srgb"],
				"pixel": [pixel.x, pixel.y], "rgb8": [color.r8, color.g8, color.b8],
				"linear_rgb": [linear.r, linear.g, linear.b]})
	print(JSON.stringify({"event": "isolation-report", "observations": observations,
		"captures": captures, "rows": ["standard Lambert", "current toon, all bands 1",
		"same toon without repeated albedo, all bands 1"]}))
	get_tree().quit(0)
