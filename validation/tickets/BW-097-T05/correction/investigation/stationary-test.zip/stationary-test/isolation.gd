extends "res://tests/rendering/outlines_probe.gd"

func _execute() -> void:
	var rows: Array[Dictionary] = []
	var captures: Array[String] = []
	_path_index = 0
	_frame = 0
	_zooms.select(0)
	_lights.select(0)
	_antialiasing.select(0)
	var shadow_lights: Array[Light3D] = []
	for child: Node in _reference.get_children():
		if child is Light3D and child.shadow_enabled:
			shadow_lights.append(child)
	for shadow_case: int in range(3):
		for light: Light3D in shadow_lights:
			light.shadow_enabled = shadow_case == 0 or (shadow_case == 1 and light is OmniLight3D)
		for mode: String in ["pbr", "toon", "combined"]:
			_toon.button_pressed = mode != "pbr"
			var view: int = _policy["views"].find("combined" if mode == "combined" else "source")
			var first: PackedByteArray
			var previous: PackedByteArray
			var maximum_changed: int = 0
			var maximum_delta: int = 0
			var atlas: Image = Image.create(386, 218 * 32, false, Image.FORMAT_RGB8)
			for frame: int in range(32):
				var image: Image = await _image(view)
				var bytes: PackedByteArray = image.get_data()
				if frame == 0:
					first = bytes
					previous = bytes
				for reference: PackedByteArray in [first, previous]:
					var difference: Dictionary = Fixtures.color_difference(bytes, reference)
					maximum_changed = maxi(maximum_changed, difference["changed_pixels"])
					maximum_delta = maxi(maximum_delta, difference["max_rgb_delta"])
				previous = bytes
				for y: int in range(218):
					atlas.blit_rect(image, Rect2i(0, y, 386, 1), Vector2i(0, y * 32 + frame))
			var filename: String = "shadow-%d-%s-frames.png" % [shadow_case, mode]
			if atlas.save_png(_request["output"].path_join(filename)) != OK:
				_fail("Cannot retain stationary investigation.")
				return
			captures.append(filename)
			rows.append({"shadow_case": ["original", "sun-disabled", "all-disabled"][shadow_case],
				"mode": mode, "frames": 32, "max_changed_pixels": maximum_changed,
				"max_rgb_delta": maximum_delta})
	print(JSON.stringify({"event": "isolation-report", "observations": rows,
		"captures": captures, "shadow_lights": shadow_lights.size()}))
	get_tree().quit(0)
