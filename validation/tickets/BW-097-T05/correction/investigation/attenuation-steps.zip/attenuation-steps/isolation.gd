extends "res://tests/rendering/outlines_probe.gd"

func _execute() -> void:
	_path_index = 0
	_frame = 0
	_antialiasing.select(0)
	_toon.button_pressed = true
	_views.select(0)
	_apply()
	var surfaces: Array[ShaderMaterial] = []
	var meshes: Array[MeshInstance3D] = []
	ReferenceWorld.AssetLibrary.collect_meshes(_reference, meshes)
	for mesh: MeshInstance3D in meshes:
		if mesh == _posts[_reference]:
			continue
		for index: int in range(mesh.mesh.get_surface_count()):
			var material: Material = mesh.get_active_material(index)
			if material is ShaderMaterial:
				surfaces.append(material)
	var rows: Array[Dictionary] = []
	var captures: Array[String] = []
	var base_code: String = Materials.TOON.code
	for zoom: int in range(2):
		_zooms.select(zoom)
		for lighting: int in range(3):
			_lights.select(lighting)
			_apply()
			for steps: int in [0, 64, 32, 16]:
				var shader: Shader = Shader.new()
				shader.code = base_code
				if steps > 0:
					shader.code = shader.code.replace("* ATTENUATION *", "* (LIGHT_IS_DIRECTIONAL ? ATTENUATION : round(ATTENUATION * %d.0) / %d.0) *" % [steps, steps])
				for material: ShaderMaterial in surfaces:
					material.shader = shader
				for warmup: int in range(16):
					await RenderingServer.frame_post_draw
				var first: PackedByteArray
				var previous: PackedByteArray
				var maximum_changed: int = 0
				var maximum_delta: int = 0
				var atlas: Image = Image.create(386, 218 * 32, false, Image.FORMAT_RGB8)
				for frame: int in range(32):
					await _settle()
					var image: Image = _reference.get_texture().get_image()
					image.convert(Image.FORMAT_RGB8)
					var bytes: PackedByteArray = image.get_data()
					if frame == 0:
						first = bytes
						previous = bytes
						var still_name: String = "steps-%d-z%d-l%d.png" % [steps, zoom, lighting]
						if image.save_png(_request["output"].path_join(still_name)) != OK:
							_fail("Cannot retain local-light still.")
							return
						captures.append(still_name)
					for reference: PackedByteArray in [first, previous]:
						var difference: Dictionary = Fixtures.color_difference(bytes, reference)
						maximum_changed = maxi(maximum_changed, difference["changed_pixels"])
						maximum_delta = maxi(maximum_delta, difference["max_rgb_delta"])
					previous = bytes
					for y: int in range(218):
						atlas.blit_rect(image, Rect2i(0, y, 386, 1), Vector2i(0, y * 32 + frame))
				var filename: String = "steps-%d-z%d-l%d-frames.png" % [steps, zoom, lighting]
				if atlas.save_png(_request["output"].path_join(filename)) != OK:
					_fail("Cannot retain local-light frames.")
					return
				captures.append(filename)
				rows.append({"steps": steps, "zoom": zoom, "lighting": lighting,
					"frames": 32, "max_changed_pixels": maximum_changed,
					"max_rgb_delta": maximum_delta, "executed_shader": shader.code})
	print(JSON.stringify({"event": "isolation-report", "observations": rows, "captures": captures}))
	get_tree().quit(0)
