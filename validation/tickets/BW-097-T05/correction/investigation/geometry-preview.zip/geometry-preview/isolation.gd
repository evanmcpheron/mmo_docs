extends "res://tests/rendering/outlines_probe.gd"

func _execute() -> void:
	for zoom: int in range(2):
		for label: String in _policy["geometry_cases"]:
			await _still(label, zoom, 0, 0)
	print(JSON.stringify({"event": "isolation-report", "observations": _observations,
		"captures": _captures, "source_settings": _policy,
		"key_light_direction": _reference.key_light_direction()}))
	get_tree().quit(0)
