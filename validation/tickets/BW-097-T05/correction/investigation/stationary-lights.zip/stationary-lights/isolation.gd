extends "res://tests/rendering/outlines_probe.gd"

func _execute() -> void:
	_path_index = 0
	_frame = 0
	_zooms.select(0)
	_lights.select(0)
	_antialiasing.select(0)
	_toon.button_pressed = true
	_views.select(0)
	_apply()
	var lights: Array[Light3D] = []
	var energies: Array[float] = []
	var environment: Environment
	for child: Node in _reference.get_children():
		if child is Light3D:
			lights.append(child)
			energies.append(child.light_energy)
		if child is WorldEnvironment:
			environment = child.environment
	var rows: Array[Dictionary] = []
	var captures: Array[String] = []
	for selected: int in [-2, -1, 0, 1, 2, 3]:
		var mode: String = ["all", "ambient-only", "sun-only", "fill-only", "lantern-only", "no-ambient"][selected + 2]
		for index: int in range(lights.size()):
			lights[index].light_energy = energies[index] if selected in [-2, 3] or selected == index else 0.0
		environment.ambient_light_energy = 0.0 if selected == 3 else 0.25
		for warmup: int in range(16):
			await RenderingServer.frame_post_draw
		var first: PackedByteArray
		var previous: PackedByteArray
		var maximum_changed: int = 0
		var maximum_delta: int = 0
		var atlas: Image = Image.create(386, 218 * 32, false, Image.FORMAT_RGB8)
		for frame: int in range(32):
			if mode == "reapply":
				_apply()
			await _settle()
			var image: Image = _reference.get_texture().get_image()
			image.convert(Image.FORMAT_RGB8)
			var bytes: PackedByteArray = image.get_data()
			if frame == 0:
				first = bytes
				previous = bytes
			for reference: PackedByteArray in [first, previous]:
				var difference: Dictionary = Fixtures.color_difference(bytes, reference)
				maximum_changed = maxi(maximum_changed, difference["changed_pixels"])
				maximum_delta = maxi(maximum_delta, difference["max_rgb_delta"])
			previous = bytes
			for y: int in range(218):
				atlas.blit_rect(image, Rect2i(0, y, 386, 1), Vector2i(0, y * 32 + frame))
		var filename: String = mode + "-frames.png"
		if atlas.save_png(_request["output"].path_join(filename)) != OK:
			_fail("Cannot retain stationary deep investigation.")
			return
		captures.append(filename)
		rows.append({"mode": mode, "frames": 32, "max_changed_pixels": maximum_changed,
			"max_rgb_delta": maximum_delta, "selected_light": selected})
	print(JSON.stringify({"event": "isolation-report", "observations": rows,
		"captures": captures, "debanding": _reference.use_debanding,
		"taa": _reference.use_taa, "scaling": _reference.scaling_3d_scale}))
	get_tree().quit(0)
