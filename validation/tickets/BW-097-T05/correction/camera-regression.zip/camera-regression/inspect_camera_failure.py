from pathlib import Path
import json
from PIL import Image,ImageChops
root=Path('/Users/le-evanmcpheron/Documents/Godot/briarwake/artifacts/t05-correction-final-suite/camera-regression')
r=json.loads((root/'run.json').read_text());sequence=next(s for s in r['actual']['sequences'] if s['id']=='p4-z1-stationary-corrected')
atlas=Image.open(root/sequence['atlas']).convert('RGB'); frames=[]
for t in range(64):
 image=Image.new('RGB',(atlas.width,atlas.height//64))
 for y in range(image.height):image.paste(atlas.crop((0,y*64+t,atlas.width,y*64+t+1)),(0,y))
 frames.append(image)
union=set();maximum=0
for frame in frames[1:]:
 difference=ImageChops.difference(frames[0],frame);bbox=difference.getbbox()
 if not bbox:continue
 maximum=max(maximum,max(x[1] for x in difference.getextrema()))
 for y in range(bbox[1],bbox[3]):
  for x in range(bbox[0],bbox[2]):
   if max(difference.getpixel((x,y))):union.add((x,y))
points=sorted(union);fields=['camera','desired_camera','projected_actor','projected_origin','actor','source_actor','anchors','basis','residual_pixels','correction_physical']
result={'sequence':sequence['id'],'first_frame_max_RGB8_delta':maximum,'union_changed_pixels':len(points),'bounds':[min(x for x,y in points),min(y for x,y in points),max(x for x,y in points),max(y for x,y in points)],'pixels':points,'metadata_identity':{field:all(row[field]==sequence['frames'][0][field] for row in sequence['frames']) for field in fields},'interpretation':'PBR color differences occur while recorded camera, actor, anchors and projection fields remain fixed. This is not proof of a specific light/driver defect or approval to change a bound.'}
(root/'stationary-failure-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
